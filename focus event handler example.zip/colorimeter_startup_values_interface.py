from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.uic import loadUi
from PyQt5 import QtCore
import sys



class SecondUI(QMainWindow):
    def __init__(self):
        super(SecondUI, self).__init__()

        # Load interface
        loadUi ("colorimeter_startup_values_interface.ui", self)


if __name__ == "__main__":
    
    # This will not run on import !

    # Enable High DPI display with PyQt5
    QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    # QApplication.setHighDpiScaleFactorRoundingPolicy (QtCore.Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    QApplication.setHighDpiScaleFactorRoundingPolicy (QtCore.Qt.HighDpiScaleFactorRoundingPolicy.Ceil)
    
    app2 = QApplication (sys.argv)
    window2 = SecondUI()
    window2.show()
    app2.exec_()