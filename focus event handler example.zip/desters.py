def fct(a,b):
    print (a+b)
    print (var_global)

def fct2 (c):
    print (c*c)
    fct (2,3)


var_global = 3

fct2(5)
